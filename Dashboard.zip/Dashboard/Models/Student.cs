using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Dashboard.Models
{
    [Table("Student")]
    public class Student
    {
        [Key]
        [Column("student_id")]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int StudentId { get; set; }

        [Column("username")]
        [Required]
        [MaxLength(50)]
        public string Username { get; set; } = string.Empty;

        [Column("name")]
        [Required]
        [MaxLength(100)]
        public string Name { get; set; } = string.Empty;

        [Column("password")]
        [Required]
        [MaxLength(255)]
        public string Password { get; set; } = string.Empty;

        [Column("teacher_id")]
        public int? TeacherId { get; set; }

        [ForeignKey("TeacherId")]
        public Teacher? AssignedTeacher { get; set; }

        [Column("capability_level")]
        [MaxLength(20)]
        public string CapabilityLevel { get; set; } = "Basic";

        [Column("is_active")]
        public bool IsActive { get; set; } = true;

        [Column("archived_at")]
        public DateTime? ArchivedAt { get; set; }
    }
}
